
// Company class
function Company(name, location) {
    this.name = name;
    this.location = location;
    this.employees = [];
}

// Method to hire an employee
Company.prototype.hire = function(employeeName) {
    this.employees.push(employeeName);
    console.log(employeeName + " has been hired at " + this.name);
};

// Method to display company details
Company.prototype.display = function() {
    console.log("Company: " + this.name);
    console.log("Location: " + this.location);
    console.log("Employees: " + (this.employees.length > 0 ? this.employees.join(", ") : "No employees"));
};

// Software Company class inheriting from Company

function SoftwareCompany(name, location, techStack) {
    Company.call(this, name, location);
    this.techStack = techStack;
}

// Set Software Company prototype to be an instance of Company
SoftwareCompany.prototype = Object.create(Company.prototype);
SoftwareCompany.prototype.constructor = SoftwareCompany;

// Method to display software company details
SoftwareCompany.prototype.display = function() {
    Company.prototype.display.call(this);
    console.log("Tech Stack: " + this.techStack);
};

// Manufacturing Company class inheriting from Company

function ManufacturingCompany(name, location, productType) {
    Company.call(this, name, location);
    this.productType = productType;
}

// Set Manufacturing Company prototype to be an instance of Company
ManufacturingCompany.prototype = Object.create(Company.prototype);
ManufacturingCompany.prototype.constructor = ManufacturingCompany;

// Method to display manufacturing company details
ManufacturingCompany.prototype.display = function() {
    Company.prototype.display.call(this);
    console.log("Product Type: " + this.productType);
};

// Test the inheritance hierarchy

// Creating an instance of Software Company
var softwareCompany = new SoftwareCompany("Tech Solutions", "Hyderabad", "JavaScript, Python, AWS");
console.log("Software Company:");
softwareCompany.hire("Satvik");
softwareCompany.hire("Karthik");
softwareCompany.display();

// Creating an instance of Manufacturing Company
var manufacturingCompany = new ManufacturingCompany("Widgets", "Hyderabad", "Electronics");
console.log("\nManufacturing Company:");
manufacturingCompany.hire("Tarun");
manufacturingCompany.hire("Kunal");
manufacturingCompany.display();
