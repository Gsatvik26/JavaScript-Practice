let status = {
    1: "one",
    2: "two",
    3: "three",
    4: "four",
};

let users_json = [{
        userId: 1,
        name: "Varun",
        profilePicture: "https://images.nightcafe.studio/jobs/mWfF1s7OOVg5DMTYiNZ8/mWfF1s7OOVg5DMTYiNZ8--4--qccau.jpg?tr=w-1600,c-at_max",
        statusMessage: "Hello There",
        presence: 1,
        messages: []
    },
    {
        userId: 2,
        name: "Karthik",
        profilePicture: "https://preview.redd.it/hlxen8gtwpm01.jpg?width=640&crop=smart&auto=webp&v=enabled&s=a3c43bcbfc1db31d542ef67071559264358b3d2b",
        statusMessage: "On and Off",
        presence: 3,
        messages: []
    },
    {
        userId: 3,
        name: "Tarun",
        profilePicture: "https://mir-s3-cdn-cf.behance.net/project_modules/fs/6a3f5237411193.573f25019c8bf.jpg",
        statusMessage: "Hi There!",
        presence: 3,
        messages: []
    },
    {
        userId: 4,
        name: "Lalith",
        profilePicture: "https://images.nightcafe.studio/jobs/mWfF1s7OOVg5DMTYiNZ8/mWfF1s7OOVg5DMTYiNZ8--4--qccau.jpg?tr=w-1600,c-at_max",
        statusMessage: "I am a rockstar",
        presence: 1,
        messages: []
    },
    {
        userId: 5,
        name: "Yatin",
        profilePicture: "https://64.media.tumblr.com/21de4501827aba1c6463ce2ae6a36780/tumblr_ps5le9xxRb1w9a5vgo1_1280.jpg",
        statusMessage: "Hello",
        presence: 4,
        messages: []
    }
];

document.addEventListener("DOMContentLoaded", display);

function display() {
    document.getElementById('updateUserForm').style.display = 'none';

    let usersContainer = document.querySelector('.users-container');
    usersContainer.innerHTML = '';

    users_json.forEach(user => {
        let userElement = document.createElement('div');
        userElement.className = 'user';

        let presenceClass = {
            1: 'one',
            2: 'two',
            3: 'three',
            4: 'four'
        }[user.presence];

        userElement.innerHTML = `
            <div class="img-container">
                <img src="${user.profilePicture}" class="user-image ${presenceClass}" alt="user image" />
            </div>
            <div class="user-detail">
                <p class="user-name">${user.name}</p>
                <p class="user-message">${user.statusMessage}</p>
            </div>
            <div class='three-btn'>
                <div class="dropdown">
                    <a class="" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i></a>
                    <ul class="dropdown-menu">
                        <li><button id='USR000${user.userId}' onclick='deleteBuddy(${user.userId})' class="dropdown-item">Delete</button></li>
                        <li><button id='update-USR000${user.userId}' onclick='updateBuddy(${user.userId})' class="dropdown-item">Update</button></li>
                        <li><button onclick='startMessaging(${user.userId})' class="dropdown-item">Message</button></li> <!-- Add this line for messaging -->
                    </ul>
                </div>
            </div>
        `;
        usersContainer.appendChild(userElement);
    });
}
function addBuddy(user) {
    let usersContainer = document.querySelector('.users-container');
    let userElement = document.createElement('div');
    userElement.className = 'user';

    let presenceClass = {
        1: 'one',
        2: 'two',
        3: 'three',
        4: 'four'
    }[user.presence];

    userElement.innerHTML = `
        <div class="img-container">
            <img src="${user.profilePicture}" class="user-image ${presenceClass}" alt="user image" />
        </div>
        <div class="user-detail">
            <p class="user-name">${user.name}</p>
            <p class="user-message">${user.statusMessage}</p>
        </div>
        <div class='three-btn'>
            <div class="dropdown">
                <a class="" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i></a>
                <ul class="dropdown-menu">
                    <li><button id='USR000${user.userId}' onclick='deleteBuddy(${user.userId})' class="dropdown-item">Delete</button></li>
                    <li><button id='update-USR000${user.userId}' onclick='updateBuddy(${user.userId})' class="dropdown-item">Update</button></li>
                </ul>
            </div>
        </div>
    `;

    usersContainer.prepend(userElement);

    document.getElementById('name').value = "";
    document.getElementById('statusMessage').value = "";
    document.getElementById('profilePicLink').value = "";
    document.getElementById('presence').value = 1;
}

function startMessaging(userId) {
    let currentUser = users_json.find(user => user.userId === userId);
    if (currentUser) {
        let message = prompt("Enter your message:");
        if (message) {
            let recipientId = parseInt(prompt("Enter recipient's user ID:"));
            let recipient = users_json.find(user => user.userId === recipientId);
            if (recipient) {
                currentUser.messages.push({ to: recipientId, message: message });
                recipient.messages.push({ from: userId, message: message });
                alert("Message sent successfully!");
            } else {
                alert("Recipient not found!");
            }
        }
    }
}
function addUser(event) {
    event.preventDefault();

    document.getElementById('addUserForm').style.display = 'block';     
    document.getElementById('updateUserForm').style.display = 'none';

    let name1 = document.getElementById('name').value;
    let statusMessage1 = document.getElementById('statusMessage').value;
    let profilePicLink1 = document.getElementById('profilePicLink').value;
    let presence1 = document.getElementById('presence').value;
    
    let newUser = {
        userId: Date.now(),
        name: name1,
        profilePicture: profilePicLink1,
        statusMessage: statusMessage1,
        presence: parseInt(presence1),
    };
    
    users_json.unshift(newUser);
    console.log(users_json);
    addBuddy(newUser);
}
function updateBuddy(userId) {
    let user = users_json.find(user => user.userId === userId);
    if (user) {
        document.getElementById('updateName').value = user.name;
        document.getElementById('updateStatusMessage').value = user.statusMessage;
        document.getElementById('updateProfilePicLink').value = user.profilePicture;
        document.getElementById('updatePresence').value = user.presence;

        document.getElementById('addUserForm').style.display = 'none';
        document.getElementById('updateUserForm').style.display = 'block';

            document.getElementById('updateUserForm').onsubmit = function() {
            user.name = document.getElementById('updateName').value;
            user.statusMessage = document.getElementById('updateStatusMessage').value;
            user.profilePicture = document.getElementById('updateProfilePicLink').value;
            user.presence = parseInt(document.getElementById('updatePresence').value);

            display();
            document.getElementById('addUserForm').style.display = 'block';
            document.getElementById('updateUserForm').style.display = 'none';

            document.getElementById('name').value = "";
            document.getElementById('statusMessage').value = "";
            document.getElementById('profilePicLink').value = "";
            document.getElementById('presence').value = 1;
            return false; 
        }
    }
}


function deleteBuddy(userId) {
    users_json = users_json.filter(user => user.userId !== userId);
    display();
}
