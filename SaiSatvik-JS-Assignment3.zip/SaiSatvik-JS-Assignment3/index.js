const displayDays = document.getElementById("days");
const displayHours = document.getElementById("hours");
const displayMinutes = document.getElementById("mins");
const displaySeconds = document.getElementById("secs");

const inputDays = document.getElementById("daysIn");
const inputHours = document.getElementById("hoursIn");
const inputMinutes = document.getElementById("minsIn");
const inputSeconds = document.getElementById("secsIn");

let days = parseInt(inputDays.value) || 0;
let hours = parseInt(inputHours.value) || 0;
let minutes = parseInt(inputMinutes.value) || 0;
let seconds = parseInt(inputSeconds.value) || 0;

const setButton = document.getElementById("setTimer");
const startButton = document.getElementById("start");
const pauseButton = document.getElementById("stop");
const resetButton = document.getElementById("reset");

let timerInterval;
let timeLeft;

setButton.addEventListener("click", () => {
    days = parseInt(inputDays.value) || 0;
    hours = parseInt(inputHours.value) || 0;
    minutes = parseInt(inputMinutes.value) || 0;
    seconds = parseInt(inputSeconds.value) || 0;
    inputDays.value = "0";
    inputHours.value = "0";
    inputMinutes.value = "0";
    inputSeconds.value = "0";
    updateDisplay(days, hours, minutes, seconds);
});

pauseButton.addEventListener("click", () => {
    clearInterval(timerInterval);
    timeLeft = getTimeRemaining();
    timerInterval = undefined;
});

startButton.addEventListener("click", () => {
    let totalSeconds = timeLeft || convertToSeconds(days, hours, minutes, seconds);
    if (totalSeconds === 0) {
        return;
    }
    startTimer(totalSeconds);
});

resetButton.addEventListener("click", () => {
    clearInterval(timerInterval);
    timerInterval = undefined;
    days = hours = minutes = seconds = 0;
    timeLeft = 0;
    updateDisplay(0, 0, 0, 0);
});

const startTimer = (totalSeconds) => {
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        totalSeconds--;
        updateDisplay(
            Math.floor(totalSeconds / (24 * 3600)),
            Math.floor((totalSeconds % (24 * 3600)) / 3600),
            Math.floor((totalSeconds % 3600) / 60),
            totalSeconds % 60
        );
        if (totalSeconds <= 0) {
            clearInterval(timerInterval);
        }
    }, 1000);
};

const updateDisplay = (d, h, m, s) => {
    displayDays.textContent = (d < 10) ? "0" + d : d;
    displayHours.textContent = (h < 10) ? "0" + h : h;
    displayMinutes.textContent = (m < 10) ? "0" + m : m;
    displaySeconds.textContent = (s < 10) ? "0" + s : s;
};

const getTimeRemaining = () => {
    return convertToSeconds(
        parseInt(displayDays.textContent) || 0,
        parseInt(displayHours.textContent) || 0,
        parseInt(displayMinutes.textContent) || 0,
        parseInt(displaySeconds.textContent) || 0
    );
};

const convertToSeconds = (d, h, m, s) => {
    return d * 24 * 3600 + h * 3600 + m * 60 + s;
};
