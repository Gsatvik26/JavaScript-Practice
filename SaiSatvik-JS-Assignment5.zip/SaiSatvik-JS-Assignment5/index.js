document.addEventListener("DOMContentLoaded", function () {
    const userTableBody = document.querySelector("#userTable");
    const addUserForm = document.getElementById("addUserForm");
    const editModal = document.getElementById("editModal");
    const closeModal = document.querySelector(".close");
  
  function fetchUsers() {
      fetch("https://66596e3cde346625136c55ce.mockapi.io/ajax/Task")
        .then((response) => response.json())
        .then((users) => {
          // console.log(users);
          userTableBody.innerHTML = `
                  <div class="table__row table__header">
                      <span class="table__cell">TaskName</span>
                      <span class="table__cell DueDate">Due Date</span>
                      <span class="table__cell Assigned To">Assigned To</span>
                      <span class="table__cell">Functions</span>
                  </div>
                  `;
          users.forEach((user) => addUserRow(user));
        });
    }

    
   function addUserRow(user) {
      const row = document.createElement("div");
      row.classList.add("table__row");
      row.innerHTML = `
          <span id="Taskname${user.id}" class="table__cell">${user.TaskName}</span>
          <span id="DueDate${user.id}" class="table__cell DueDate">${user.DueDate}</span>
          <span id="AssignedTo${user.id}" class="table__cell state">${user.AssignedTo}</span>
          <span id="func${user.id}" class="table__cell func__cell">
              <button onclick="editUser(${user.id})" class="edit-btn">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen-fill" viewBox="0 0 16 16">
                      <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001"/>
                    </svg>
              </button>
              <button onclick="deleteUser(${user.id})" class="delete-btn">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
                      <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5m-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5M4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06m6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528M8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5"/>
                    </svg>
              </button>
          </span>
          `;
      userTableBody.appendChild(row);
    }

    function fetchUsersById(Id) {
      fetch(
        `https://66596e3cde346625136c55ce.mockapi.io/ajax/Task/${Id}`
      )
        .then((response) => response.json())
        .then((user) => {
          document.getElementById("deClick").innerHTML += user.TaskName;
          // console.log(user);
        });
    }
  
    document.querySelector("#addForm").addEventListener("click", function () {
      addUserForm.style.display = "block";
      userTableBody.style.display = "none";
      
      });
  
    addUserForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const TaskName = document.getElementById("TaskName").value;
      const DueDate = document.getElementById("DueDate").value;
      const AssignedTo = document.getElementById("AssignedTo").value;
  
      fetch("https://66596e3cde346625136c55ce.mockapi.io/ajax/Task", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ TaskName, DueDate, AssignedTo }),
      })
        .then((response) => response.json())
        .then((user) => {
          addUserRow(user);
          addUserForm.reset();
        });
      addUserForm.style.display = "none";
      userTableBody.style.display = "block";
    });
  
    window.editUser = function (Id) {
        let editUserId = Id;
        fetchUsersById(Id);
  
        const btnEle = document.createElement('button');
        btnEle.id = 'saveEdit';
        btnEle.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-up-circle-fill" viewBox="0 0 16 16">
                <path d="M16 8A8 8 0 1 0 0 8a8 8 0 0 0 16 0m-7.5 3.5a.5.5 0 0 1-1 0V5.707L5.354 7.854a.5.5 0 1 1-.708-.708l3-3a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 5.707z"/>
            </svg>
        `;
  
        const buttn = document.getElementById('func' + Id);
  
        if (buttn) {
            buttn.appendChild(btnEle);
  
            document.querySelector(`#func${Id} .edit-btn`).style.width = '74px';
             document.querySelector(`#func${Id} .delete-btn`).style.width = '74px';
    
            fetch(`https://66596e3cde346625136c55ce.mockapi.io/ajax/Task/${Id}`)
                .then((response) => response.json())
                .then((user) => {
    
                  const name = document.getElementById("Taskname"+Id);
                  const inptName =  document.createElement('input');
                  inptName.id = 'inptName'+Id;
                  inptName.value = name.textContent;
                  name.append(inptName);
                
                  const age = document.getElementById("DueDate"+Id);
                  const inptAge =  document.createElement('input');
                  inptAge.id = 'inptAge'+Id;
                  inptAge.value = age.textContent;
                  age.append(inptAge);
  
                  const state = document.getElementById("AssignedTo"+Id);
                  const inptState =  document.createElement('input');
                  inptState.id = 'inptState'+Id;
                  inptState.value = state.textContent;
                  state.append(inptState);
                });
    
            btnEle.addEventListener("click", function () {
                const TaskName = document.getElementById("inptName"+Id).value;
                const DueDate = document.getElementById("inptAge"+Id).value;
                const AssignedTo = document.getElementById("inptState"+Id).value;
    
                fetch(`https://66596e3cde346625136c55ce.mockapi.io/ajax/Task/${editUserId}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ TaskName, DueDate, AssignedTo }),
                })
                    .then((response) => response.json())
                    .then((user) => {
                        fetchUsers();
                        document.querySelector('.edit-btn').style.width = '50%';
                        document.querySelector('.delete-btn').style.width = '50%';
                    });
            });
        } else {
            console.error(`Element with ID 'func${Id}' not found.`);
        }
    };
    
  
  
    window.deleteUser = function (id) {
      fetchUsersById(id);
      document.querySelector(".main").style.backgroundColor = "rgba(0, 0, 0, 0.5)";
      document.querySelector(".popup").style.display = "block";
      const btns = document.querySelectorAll(".pop-btns button, .close");
  
      btns.forEach((btn) => {
        btn.addEventListener("click", () => {
          if (btn.textContent == "Delete") {
            document.querySelector(".popup").style.display = "none";
            fetch(
              `https://66596e3cde346625136c55ce.mockapi.io/ajax/Task/${id}`,
              {
                method: "DELETE",
              }
            )
              .then((response) => response.json())
              .then(() => {
                fetchUsers();
              });
          } else {
            document.querySelector(".popup").style.display = "none";
          }
          document.querySelector(".main").style.backgroundColor =
            "rgba(0, 0, 0, 0)";
          document.getElementById('deClick').textContent = "Deleting: ";
        });
      });
    };
  
    closeModal.onclick = function () {
      editModal.style.display = "none";
    };
  
    window.onclick = function (event) {
      if (event.target == editModal) {
        editModal.style.display = "none";
      }
    };
  
    fetchUsers();
  });
  